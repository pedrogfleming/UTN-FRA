/*
 * bibliotecaMenu.h
 *
 *  Created on: 8 abr. 2021
 *      Author: Pedro
 */

#ifndef BIBLIOTECAMENU_H_
#define BIBLIOTECAMENU_H_
int mostrarMenu(int* punteroMenu);
//Brief Muestra un menu predeterminado y le pide al usuario que ingrese una opcion
//recibe como parametro un puntero
//Retorna un int si funcion�
int mostrarSubMenuVender(int* subComandoV);
//Brief Muestra un menu predeterminado y le pide al usuario que ingrese una opcion
//recibe como parametro un puntero
//Retorna un int si funcion�

#endif /* BIBLIOTECAMENU_H_ */
