/*
 ============================================================================
 Name        : cursoIngresoParcial2021Ej1.c
 Author      : Geraghty Fleming Pedro 1E
 Version     :
 Copyright   : Your copyright notice
 Description : Debemos realizar la carga de una compra de 5(cinco) productos de desinfecci�n de cada una debo obtener los siguientes datos:
				el nombre del producto el tipo de producto (validar "ALCOHOL", "IAC" o "QUAT"),
				el precio (validar entre 100 y 300),
				la cantidad de unidades (no puede ser 0 o negativo y no debe superar las 1000 unidades),
				Categoria ("desinfectante", "bactericida", "detergente" ) y el fabricante.
					Se debe Informar al usuario lo siguiente:
						a) El promedio de cantidad por tipo de producto
						b) La categoria con mas cantidad de unidades en total de la compra
						c) Cu�ntas unidades de detergente con precios menos a 200 (inclusive) se compraron en total
						d) el fabricante y Categoria del m�s caro de los productos

============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	setbuf(stdout,NULL);



	return EXIT_SUCCESS;
}
