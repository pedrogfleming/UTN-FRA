

#ifndef ENTIDADES_H_
#define ENTIDADES_H_
#include "calculos.h"
#include "estructuras.h"
#include "informes.h"
#include "menu.h"
#include "utn.h"
#include "arrayEmployees.h"
#endif /* ENTIDADES_H_ */
