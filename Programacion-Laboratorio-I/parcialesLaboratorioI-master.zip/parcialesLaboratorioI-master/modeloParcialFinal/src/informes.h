/*
 * informes.h
 *
 *  Created on: 24 jun. 2021
 *      Author: Pedro
 */

#ifndef INFORMES_H_
#define INFORMES_H_

int cantidadEntradas_Sala(void* pElement, int* acumuladorEntradasVendidas, float* facturacion);

#endif /* INFORMES_H_ */
