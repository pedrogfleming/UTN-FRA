/*
 * informes.c
 *
 *  Created on: 8 may. 2021
 *      Author: Pedro
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estructuras.h"
#include "utn.h"

