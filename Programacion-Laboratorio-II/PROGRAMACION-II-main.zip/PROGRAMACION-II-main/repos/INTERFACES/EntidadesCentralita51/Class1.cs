﻿using System;

namespace EntidadesCentralita51
{
    public class Class1
    {
    }
}
