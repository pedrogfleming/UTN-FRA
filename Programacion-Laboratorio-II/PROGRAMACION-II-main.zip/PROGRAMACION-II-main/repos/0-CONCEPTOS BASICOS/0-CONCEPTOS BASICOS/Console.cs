﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ClassLibrary1;
namespace _0_CONCEPTOS_BASICOS
{
    class Console
    {
        
        static void Main(string[] args)
        {

            Console.WriteLine(Class1.MetodoEstatico());
        }
    }
}

