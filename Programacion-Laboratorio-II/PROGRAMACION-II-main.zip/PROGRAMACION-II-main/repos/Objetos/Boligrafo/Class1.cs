﻿using System;

namespace Boligrafo
{
    public class Class1
    {
    }
}
