﻿using System;
using System.IO;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //StreamWriter aux = new StreamWriter();

        }
    }
}
