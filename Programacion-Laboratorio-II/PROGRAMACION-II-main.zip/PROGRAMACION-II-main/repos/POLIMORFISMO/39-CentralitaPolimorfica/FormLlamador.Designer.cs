﻿
namespace _41_CentralitaExcepciones
{
    partial class FormLlamador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNroDestino = new System.Windows.Forms.TextBox();
            this.btnMarcar1 = new System.Windows.Forms.Button();
            this.btnMarcar3 = new System.Windows.Forms.Button();
            this.btnMarcar2 = new System.Windows.Forms.Button();
            this.btnMarcar4 = new System.Windows.Forms.Button();
            this.btnMarcar5 = new System.Windows.Forms.Button();
            this.btnMarcar6 = new System.Windows.Forms.Button();
            this.btnMarcar7 = new System.Windows.Forms.Button();
            this.btnMarcar8 = new System.Windows.Forms.Button();
            this.btnMarcar9 = new System.Windows.Forms.Button();
            this.btnLlamar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.cmbFranja = new System.Windows.Forms.ComboBox();
            this.txtNroOrigen = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnMarcarAsterico = new System.Windows.Forms.Button();
            this.btnMarcar0 = new System.Windows.Forms.Button();
            this.btnMarcarNumeral = new System.Windows.Forms.Button();
            this.gboxPanel = new System.Windows.Forms.GroupBox();
            this.gboxPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNroDestino
            // 
            this.txtNroDestino.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNroDestino.Location = new System.Drawing.Point(12, 24);
            this.txtNroDestino.Name = "txtNroDestino";
            this.txtNroDestino.Size = new System.Drawing.Size(558, 36);
            this.txtNroDestino.TabIndex = 0;
            this.txtNroDestino.Text = "Nro Destino";
            // 
            // btnMarcar1
            // 
            this.btnMarcar1.Location = new System.Drawing.Point(18, 13);
            this.btnMarcar1.Name = "btnMarcar1";
            this.btnMarcar1.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar1.TabIndex = 1;
            this.btnMarcar1.Text = "1";
            this.btnMarcar1.UseVisualStyleBackColor = true;
            // 
            // btnMarcar3
            // 
            this.btnMarcar3.Location = new System.Drawing.Point(126, 13);
            this.btnMarcar3.Name = "btnMarcar3";
            this.btnMarcar3.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar3.TabIndex = 2;
            this.btnMarcar3.Text = "3";
            this.btnMarcar3.UseVisualStyleBackColor = true;
            // 
            // btnMarcar2
            // 
            this.btnMarcar2.Location = new System.Drawing.Point(72, 13);
            this.btnMarcar2.Name = "btnMarcar2";
            this.btnMarcar2.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar2.TabIndex = 2;
            this.btnMarcar2.Text = "2";
            this.btnMarcar2.UseVisualStyleBackColor = true;
            // 
            // btnMarcar4
            // 
            this.btnMarcar4.Location = new System.Drawing.Point(18, 67);
            this.btnMarcar4.Name = "btnMarcar4";
            this.btnMarcar4.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar4.TabIndex = 3;
            this.btnMarcar4.Text = "4";
            this.btnMarcar4.UseVisualStyleBackColor = true;
            // 
            // btnMarcar5
            // 
            this.btnMarcar5.Location = new System.Drawing.Point(72, 67);
            this.btnMarcar5.Name = "btnMarcar5";
            this.btnMarcar5.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar5.TabIndex = 4;
            this.btnMarcar5.Text = "5";
            this.btnMarcar5.UseVisualStyleBackColor = true;
            // 
            // btnMarcar6
            // 
            this.btnMarcar6.Location = new System.Drawing.Point(126, 67);
            this.btnMarcar6.Name = "btnMarcar6";
            this.btnMarcar6.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar6.TabIndex = 5;
            this.btnMarcar6.Text = "6";
            this.btnMarcar6.UseVisualStyleBackColor = true;
            // 
            // btnMarcar7
            // 
            this.btnMarcar7.Location = new System.Drawing.Point(18, 121);
            this.btnMarcar7.Name = "btnMarcar7";
            this.btnMarcar7.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar7.TabIndex = 6;
            this.btnMarcar7.Text = "7";
            this.btnMarcar7.UseVisualStyleBackColor = true;
            // 
            // btnMarcar8
            // 
            this.btnMarcar8.Location = new System.Drawing.Point(72, 121);
            this.btnMarcar8.Name = "btnMarcar8";
            this.btnMarcar8.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar8.TabIndex = 7;
            this.btnMarcar8.Text = "8";
            this.btnMarcar8.UseVisualStyleBackColor = true;
            // 
            // btnMarcar9
            // 
            this.btnMarcar9.Location = new System.Drawing.Point(126, 121);
            this.btnMarcar9.Name = "btnMarcar9";
            this.btnMarcar9.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar9.TabIndex = 8;
            this.btnMarcar9.Text = "9";
            this.btnMarcar9.UseVisualStyleBackColor = true;
            // 
            // btnLlamar
            // 
            this.btnLlamar.Location = new System.Drawing.Point(339, 117);
            this.btnLlamar.Name = "btnLlamar";
            this.btnLlamar.Size = new System.Drawing.Size(231, 181);
            this.btnLlamar.TabIndex = 9;
            this.btnLlamar.Text = "Llamar";
            this.btnLlamar.UseVisualStyleBackColor = true;
            this.btnLlamar.Click += new System.EventHandler(this.btnLlamar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(190, 88);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(121, 102);
            this.btnLimpiar.TabIndex = 10;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // cmbFranja
            // 
            this.cmbFranja.FormattingEnabled = true;
            this.cmbFranja.Location = new System.Drawing.Point(12, 321);
            this.cmbFranja.Name = "cmbFranja";
            this.cmbFranja.Size = new System.Drawing.Size(558, 23);
            this.cmbFranja.TabIndex = 12;
            this.cmbFranja.Text = "Franja";
            // 
            // txtNroOrigen
            // 
            this.txtNroOrigen.Location = new System.Drawing.Point(339, 88);
            this.txtNroOrigen.Name = "txtNroOrigen";
            this.txtNroOrigen.Size = new System.Drawing.Size(231, 23);
            this.txtNroOrigen.TabIndex = 14;
            this.txtNroOrigen.Text = "Nro Origen";
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(190, 206);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(121, 92);
            this.btnSalir.TabIndex = 15;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnMarcarAsterico
            // 
            this.btnMarcarAsterico.Location = new System.Drawing.Point(18, 175);
            this.btnMarcarAsterico.Name = "btnMarcarAsterico";
            this.btnMarcarAsterico.Size = new System.Drawing.Size(48, 48);
            this.btnMarcarAsterico.TabIndex = 16;
            this.btnMarcarAsterico.Text = "*";
            this.btnMarcarAsterico.UseVisualStyleBackColor = true;
            // 
            // btnMarcar0
            // 
            this.btnMarcar0.Location = new System.Drawing.Point(72, 175);
            this.btnMarcar0.Name = "btnMarcar0";
            this.btnMarcar0.Size = new System.Drawing.Size(48, 48);
            this.btnMarcar0.TabIndex = 17;
            this.btnMarcar0.Text = "0";
            this.btnMarcar0.UseVisualStyleBackColor = true;
            // 
            // btnMarcarNumeral
            // 
            this.btnMarcarNumeral.Location = new System.Drawing.Point(126, 175);
            this.btnMarcarNumeral.Name = "btnMarcarNumeral";
            this.btnMarcarNumeral.Size = new System.Drawing.Size(48, 48);
            this.btnMarcarNumeral.TabIndex = 18;
            this.btnMarcarNumeral.Text = "#";
            this.btnMarcarNumeral.UseVisualStyleBackColor = true;
            // 
            // gboxPanel
            // 
            this.gboxPanel.Controls.Add(this.btnMarcar3);
            this.gboxPanel.Controls.Add(this.btnMarcarNumeral);
            this.gboxPanel.Controls.Add(this.btnMarcar1);
            this.gboxPanel.Controls.Add(this.btnMarcar0);
            this.gboxPanel.Controls.Add(this.btnMarcar2);
            this.gboxPanel.Controls.Add(this.btnMarcarAsterico);
            this.gboxPanel.Controls.Add(this.btnMarcar4);
            this.gboxPanel.Controls.Add(this.btnMarcar5);
            this.gboxPanel.Controls.Add(this.btnMarcar6);
            this.gboxPanel.Controls.Add(this.btnMarcar7);
            this.gboxPanel.Controls.Add(this.btnMarcar8);
            this.gboxPanel.Controls.Add(this.btnMarcar9);
            this.gboxPanel.Location = new System.Drawing.Point(-6, 75);
            this.gboxPanel.Name = "gboxPanel";
            this.gboxPanel.Size = new System.Drawing.Size(190, 240);
            this.gboxPanel.TabIndex = 19;
            this.gboxPanel.TabStop = false;
            this.gboxPanel.Text = "Panel";
            // 
            // FormLlamador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 372);
            this.Controls.Add(this.gboxPanel);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.txtNroOrigen);
            this.Controls.Add(this.cmbFranja);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnLlamar);
            this.Controls.Add(this.txtNroDestino);
            this.Name = "FormLlamador";
            this.Text = "FormLlamador";
            this.Load += new System.EventHandler(this.FormLlamador_Load);
            this.gboxPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNroDestino;
        private System.Windows.Forms.Button btnMarcar1;
        private System.Windows.Forms.Button btnMarcar3;
        private System.Windows.Forms.Button btnMarcar2;
        private System.Windows.Forms.Button btnMarcar4;
        private System.Windows.Forms.Button btnMarcar5;
        private System.Windows.Forms.Button btnMarcar6;
        private System.Windows.Forms.Button btnMarcar7;
        private System.Windows.Forms.Button btnMarcar8;
        private System.Windows.Forms.Button btnMarcar9;
        private System.Windows.Forms.Button btnLlamar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.ComboBox cmbFranja;
        private System.Windows.Forms.TextBox txtNroOrigen;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnMarcarAsterico;
        private System.Windows.Forms.Button btnMarcar0;
        private System.Windows.Forms.Button btnMarcarNumeral;
        private System.Windows.Forms.GroupBox gboxPanel;
    }
}