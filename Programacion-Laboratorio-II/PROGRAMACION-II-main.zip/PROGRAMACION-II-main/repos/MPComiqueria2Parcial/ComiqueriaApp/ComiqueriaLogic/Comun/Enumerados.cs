﻿namespace ComiqueriaLogic
{
    public enum AccionesDB
    {
        Insert,
        Update,
        Delete
    }
}
