﻿using System;

namespace Entidades
{
    public enum ESistemaOperativo {ANDROID,IOS};
}
