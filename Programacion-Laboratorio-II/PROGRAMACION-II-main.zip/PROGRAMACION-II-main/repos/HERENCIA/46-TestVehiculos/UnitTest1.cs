using Microsoft.VisualStudio.TestTools.UnitTesting;
u
namespace _46_TestVehiculos
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
