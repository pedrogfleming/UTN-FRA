﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _34_EjercicioVehiculos
{
    public enum Colores { Rojo, Blanco, Azul, Gris, Negro };
}
