USE [EMPRESA];

INSERT INTO PUESTOS2 (ID_PUESTO,NOMBRE,NIVEL_AUTORIZACION)
VALUES
(1,'Director',3),
(2,'Gerente',3),
(5,'Jefe de sector',2),
(4,'Administrativo',1),
(3,'Vendedor',0),
(6,'Secretario',2);